# DRAG HS 67% v6.0.0 — oleh @JLG×celo

Aplikasi Android native (Kotlin) bertema gaming cyber. Fungsinya:

- **ENTER**: membuka Free Fire biasa (`com.dts.freefireth`) lewat launch intent resmi.
- **OVERLAY**: panel kecil mengambang bergaya menu gelap-teal: saklar ENABLE PANEL (ON/OFF), 3 preset drag HS, slider SENSI, tombol ☰ untuk pindah posisi, ▼ untuk melipat, dan × untuk menutup.
- **TRAINING**: latihan drag di dalam aplikasi dengan sensitivitas 0–100 (preset awal 67%).
- **SETTINGS**: status izin, panel on/off, sensitivitas, reset, versi.

> Nilai 67% adalah preset latihan yang dapat diubah, **bukan** klaim akurasi headshot.
> Aplikasi ini **tidak** mengubah pengaturan Free Fire, tidak menyuntikkan input, tidak membaca
> memori/data game, tidak memakai root atau Accessibility Service, dan tidak memakai internet.
> Kompatibilitas belum diuji pada perangkat tertentu (termasuk Infinix) sampai Anda mengujinya sendiri.

## Struktur folder

```
DRAG-HS-67/
├── settings.gradle.kts          Daftar modul + repositori
├── build.gradle.kts             Versi plugin: AGP 8.2.2, Kotlin 1.9.22
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties   Gradle 8.5
├── README.md
├── LICENSE
└── app/
    ├── build.gradle.kts         compileSdk 34, minSdk 29, targetSdk 34, JDK 17
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/echotex/draghs67/
        │   ├── MainActivity.kt        Layar utama (kartu, ENTER, OVERLAY, TRAINING, SETTINGS)
        │   ├── OverlayService.kt      Panel overlay (WindowManager + foreground service)
        │   ├── GameLauncher.kt        Cek & buka Free Fire
        │   ├── SettingsRepository.kt  SharedPreferences (sensitivitas, panel, statistik)
        │   ├── TrainingActivity.kt    Mode latihan + TargetView
        │   ├── SettingsActivity.kt    Halaman pengaturan
        │   ├── Presets.kt             3 preset bernama (label + nilai 67%)
        │   └── Ui.kt                  Pembantu tampilan neon + kontrol slider
        └── res/
            ├── values/ (strings.xml, colors.xml, themes.xml)
            ├── drawable/ (bg_gradient, ic_notif)
            ├── drawable-nodpi/ (ic_launcher_foreground.png, logo_gear.png: roda gigi cyan)
            └── mipmap-anydpi-v26/ (ikon adaptif)
```

Catatan: ikon adaptif di `mipmap-anydpi-v26` berlaku untuk semua perangkat karena minSdk 29, sehingga
folder `mipmap-hdpi/xhdpi/xxhdpi` tidak diperlukan. Seluruh UI dibuat lewat kode Kotlin tanpa library
eksternal, jadi tidak ada dependency yang perlu diunduh selain plugin Gradle.

## Membuka proyek di AndroidIDE

1. Ekstrak `DRAG-HS-67.zip` ke penyimpanan HP.
2. Buka AndroidIDE > **Open saved project** > pilih folder `DRAG-HS-67`.
3. Pastikan JDK 17 terpilih (AndroidIDE bawaan biasanya sudah JDK 17).

## Sinkronisasi Gradle

AndroidIDE otomatis menjalankan sync saat proyek dibuka. Jika tidak, ketuk ikon **Sync project** di toolbar.
Sync pertama membutuhkan internet untuk mengunduh Gradle 8.5 dan plugin. Setelahnya build bisa offline.
Folder `gradle/wrapper` hanya berisi file `.properties`; `gradle-wrapper.jar` tidak disertakan karena
AndroidIDE mengelola Gradle sendiri.

## Build APK

1. Ketuk **Build** > **Quick Run** atau jalankan task `assembleDebug`.
2. Hasil APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Memasang APK

Buka file `app-debug.apk` lewat pengelola file, izinkan "Pasang dari sumber ini" bila diminta, lalu ketuk Pasang.

## Memberi izin overlay

1. Di aplikasi, ketuk **OVERLAY** (atau **SETTINGS > BUKA PENGATURAN IZIN**).
2. Android membuka halaman "Tampil di atas aplikasi lain" khusus aplikasi ini.
3. Aktifkan **Izinkan tampil di atas aplikasi lain**, lalu kembali ke aplikasi.
4. Ketuk **OVERLAY** lagi. Panel tampil; geser lewat ikon ☰, matikan lewat ON atau ×.
Di Android 13+ aplikasi juga meminta izin notifikasi agar notifikasi layanan terlihat (layanan tetap jalan bila ditolak).

## Menggunakan tombol ENTER

Ketuk **ENTER**. Jika Free Fire terpasang, game dibuka dan panel overlay ikut menyala otomatis (asal izin overlay sudah diberikan dan panel aktif di Settings). Jika tidak, muncul pesan jelas. Tidak ada pesan sukses palsu.

## Menggunakan mode latihan

1. Ketuk **TRAINING**.
2. Atur sensitivitas dengan slider atau tombol − / +.
3. Seret jari di area gelap: crosshair bergerak sesuai seretan x pengali sensitivitas. Lepas jari untuk "menembak".
4. Kena jika crosshair berada di dalam lingkaran. Statistik (tembakan, kena, akurasi, streak terbaik) disimpan lokal.
5. **RESET** mengembalikan sensitivitas ke 67% dan menghapus statistik.

## Preset di panel overlay

Panel overlay punya 3 tombol preset (1, 2, 3) yang menampilkan labelnya: `drag HS 67% @levinxiterr`, `drag HS 67% @gioproxxy`, `drag sensi 67% @emeng`. Memilih preset hanya mengisi nilai sensitivitas latihan dan teks panel; tidak mengubah Free Fire. Label bisa diganti di `Presets.kt`.

## Animasi pembuka & watermark

Saat aplikasi dibuka ada animasi pembuka bergaya anime (ketuk layar untuk melewati). Watermark berbentuk tabel kecil `DEV | @JLG×celo` tampil di layar utama, Training, Settings, dan panel overlay. Nama bisa diubah di `strings.xml` (`developer`).

## Tampilan sinematik & latar salju

Layar utama, Training, dan Settings memakai langit malam bergradasi, cahaya aurora yang bergeser pelan, salju 3 lapis (paralaks), vinyet gelap di tepi layar, dan kartu bergaya kaca beku. Kodenya ada di `AnimatedBackgroundView.kt` (termasuk `VignetteView`).

## Mode offline

Aplikasi ini tidak memakai internet sama sekali: ENTER, overlay, Training, dan Settings semuanya berjalan offline. Kartu **MODE OFFLINE** di layar utama hanya penanda informasi.

## Panel bersalju

Panel overlay punya latar animasi salju (`PanelSnowView.kt`): gradasi malam, butiran salju yang turun, dan tumpukan salju di tepi atas panel.

## Awan bergerak

Spanduk langit dengan awan yang bergerak pelan (`CloudBannerView.kt`) tampil sebagai elemen UI di layar utama, Training, dan Settings.

## Training 3D

Area latihan memakai pemandangan 3D semu berperspektif: lantai bergrid, bola target berbayang yang bergoyang di atas tiang dengan jarak acak (3-7 m, makin jauh makin kecil), bayangan di lantai, getar kamera saat menembak, dan info jarak. Kodenya ada di `TargetView` (`TrainingActivity.kt`), tanpa library 3D tambahan.

## Troubleshooting build

- **Gagal mengunduh Gradle/plugin**: pastikan internet aktif saat sync pertama, lalu sync ulang.
- **Unsupported class file major version / JDK**: pilih JDK 17 di pengaturan AndroidIDE.
- **AGP 8.2.2 tidak kompatibel dengan Gradle**: AGP 8.2.x membutuhkan Gradle 8.2+; proyek ini memakai 8.5. Jangan ubah salah satunya saja.
- **Out of memory**: naikkan `-Xmx` di `gradle.properties` (mis. `-Xmx2048m`), tutup aplikasi lain.
- **Resource not found / unresolved reference R**: jalankan **Clean project**, lalu sync dan build ulang.
- **aapt2 error di ARM**: gunakan versi AndroidIDE terbaru; AndroidIDE menyuntikkan aapt2 yang cocok otomatis.
- **APK tidak terpasang**: hapus versi lama dengan tanda tangan berbeda, lalu pasang ulang.
- **Overlay tidak muncul**: periksa izin overlay, pastikan panel aktif di Settings, dan ijinkan notifikasi di Android 13+.
- **Tombol ENTER bilang belum terpasang**: aplikasi hanya mengenali Free Fire biasa (`com.dts.freefireth`), bukan Free Fire MAX.
