package com.echotex.draghs67

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.res.ColorStateList
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/**
 * Panel overlay kecil yang hanya menampilkan informasi dan kontrol milik aplikasi ini.
 * Tidak membaca layar/game, tidak menyuntikkan input, tidak memakai Accessibility Service.
 * Berjalan sebagai foreground service agar tidak dimatikan sistem saat app berada di latar belakang.
 */
class OverlayService : Service() {

    companion object {
        @Volatile
        var running = false
            private set

        const val ACTION_STOP = "com.echotex.draghs67.action.STOP"
        private const val CHANNEL_ID = "overlay_channel"
        private const val NOTIF_ID = 6701
    }

    private var wm: WindowManager? = null
    private var panel: View? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!startAsForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this) || !SettingsRepository(this).panelEnabled) {
            Toast.makeText(this, "Izin overlay belum aktif atau panel dimatikan.", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        if (panel == null) addPanel()
        running = panel != null
        return START_NOT_STICKY
    }

    private fun startAsForeground(): Boolean {
        return try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW)
            )
            val openPi = PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            val stopPi = PendingIntent.getService(
                this, 1,
                Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val stopAction = Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_notif),
                getString(R.string.notif_stop), stopPi
            ).build()
            val notification = Notification.Builder(this, CHANNEL_ID)
                .setContentTitle(getString(R.string.notif_title))
                .setContentText(getString(R.string.notif_text))
                .setSmallIcon(R.drawable.ic_notif)
                .setContentIntent(openPi)
                .addAction(stopAction)
                .setOngoing(true)
                .build()

            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, notification)
            }
            true
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal memulai layanan: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun addPanel() {
        val manager = wm ?: return
        val repo = SettingsRepository(this)

        val p = WindowManager.LayoutParams(
            dp(215),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(60)
        }

        val teal = getColor(R.color.teal_neon)

        // Baris saklar: saklar di kiri, label di kanan (seperti menu referensi).
        fun toggle(label: String, checked: Boolean): ToggleRow {
            val sw = Switch(this).apply {
                isChecked = checked
                val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
                thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, getColor(R.color.text_dim)))
                trackTintList = ColorStateList(
                    states, intArrayOf(Color.argb(255, 29, 233, 182), Color.argb(120, 127, 147, 181))
                )
                scaleX = 0.8f
                scaleY = 0.8f
                layoutParams = LinearLayout.LayoutParams(dp(46), Ui.WRAP)
            }
            val text = Ui.label(this, label, 11f, R.color.text_primary).apply {
                layoutParams = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(6), dp(3), dp(6), dp(3))
                addView(sw)
                addView(text)
                setOnClickListener { sw.toggle() }
            }
            return ToggleRow(row, sw)
        }

        fun section(label: String): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(Ui.label(this@OverlayService, label, 11f, R.color.amber, true).apply {
                setPadding(dp(8), dp(8), dp(8), dp(2))
            })
            addView(View(this@OverlayService).apply {
                setBackgroundColor(Color.argb(110, 29, 233, 182))
                layoutParams = LinearLayout.LayoutParams(Ui.MATCH, dp(1)).apply {
                    marginStart = dp(8)
                    marginEnd = dp(8)
                    bottomMargin = dp(2)
                }
            })
        }

        // ---- Header: segitiga + judul (lipat/buka), pindah posisi, tutup ----
        val title = Ui.label(this, "▼ DRAG HS 67%", 12f, R.color.teal_neon, true).apply {
            setPadding(dp(8), dp(7), dp(6), dp(7))
            layoutParams = LinearLayout.LayoutParams(0, Ui.WRAP, 1f)
        }
        val handle = Ui.label(this, "☰", 15f, R.color.teal_neon, true).apply {
            setPadding(dp(9), dp(4), dp(9), dp(4))
        }
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = p.x
                    startY = p.y
                    touchX = e.rawX
                    touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = startX + (e.rawX - touchX).toInt()
                    p.y = startY + (e.rawY - touchY).toInt()
                    clampAndUpdate()
                }
            }
            true
        }
        val close = Ui.label(this, "×", 18f, R.color.danger, true).apply {
            setPadding(dp(9), dp(2), dp(9), dp(2))
            setOnClickListener { stopSelf() }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(title)
            addView(handle)
            addView(close)
        }

        // ---- Isi panel ----
        val versionBar = Ui.label(this, "VERSION V6.0.0", 11f, R.color.teal_neon, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, dp(2))
            background = Ui.rounded(this@OverlayService, Color.argb(40, 29, 233, 182), teal, 4)
            layoutParams = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply {
                marginStart = dp(8)
                marginEnd = dp(8)
            }
        }

        val enableRow = toggle("ENABLE FUNCTIONS", true)
        enableRow.sw.setOnCheckedChangeListener { _, on -> if (!on) stopSelf() }

        val sensLabel = Ui.label(this, "SENSI: ${repo.sensitivity}", 12f, R.color.teal_neon, true)
            .apply { setPadding(dp(8), dp(8), dp(8), 0) }
        val sensBar = SeekBar(this).apply {
            max = 100
            progress = repo.sensitivity
            val tint = ColorStateList.valueOf(teal)
            progressTintList = tint
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP).apply {
                marginStart = dp(2)
                marginEnd = dp(2)
                bottomMargin = dp(6)
            }
        }
        sensBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                repo.sensitivity = progress
                sensLabel.text = "SENSI: $progress"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        val presetRows = ArrayList<ToggleRow>()
        var updating = false

        fun refreshPresets() {
            updating = true
            presetRows.forEachIndexed { i, r -> r.sw.isChecked = i == repo.activePreset }
            sensBar.progress = repo.sensitivity
            sensLabel.text = "SENSI: ${repo.sensitivity}"
            updating = false
        }

        Presets.ALL.forEachIndexed { i, preset ->
            val r = toggle(preset.label, i == repo.activePreset)
            r.sw.setOnCheckedChangeListener { _, checked ->
                if (updating) return@setOnCheckedChangeListener
                if (checked) {
                    repo.activePreset = i
                    repo.sensitivity = preset.value
                }
                refreshPresets()
            }
            presetRows.add(r)
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(versionBar)
            addView(section("FUNCTIONS CONFIG"))
            addView(enableRow.view)
            addView(section("DRAG HS MENU"))
            presetRows.forEach { addView(it.view) }
            addView(sensLabel)
            addView(sensBar)
            addView(Ui.watermark(this@OverlayService))
        }

        var expanded = true
        title.setOnClickListener {
            expanded = !expanded
            content.visibility = if (expanded) View.VISIBLE else View.GONE
            title.text = if (expanded) "▼ DRAG HS 67%" else "▶ DRAG HS 67%"
            panel?.post { clampAndUpdate() }
        }

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(header)
            addView(content)
        }
        val radius = dp(8).toFloat()
        val bar = FrameLayout(this).apply {
            addView(PanelSnowView(this@OverlayService), FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
            addView(column, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, radius)
                }
            }
            clipToOutline = true
            foreground = Ui.rounded(this@OverlayService, Color.TRANSPARENT, teal, 8)
        }

        try {
            manager.addView(bar, p)
            panel = bar
            params = p
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal menampilkan overlay: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun clampAndUpdate() {
        val v = panel ?: return
        val p = params ?: return
        val dm = resources.displayMetrics
        p.x = p.x.coerceIn(0, maxOf(0, dm.widthPixels - v.width))
        p.y = p.y.coerceIn(0, maxOf(0, dm.heightPixels - v.height))
        try {
            wm?.updateViewLayout(v, p)
        } catch (e: IllegalArgumentException) {
            // View sudah dilepas; abaikan.
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        panel?.post { clampAndUpdate() }
    }

    override fun onDestroy() {
        running = false
        panel?.let {
            try {
                wm?.removeView(it)
            } catch (e: IllegalArgumentException) {
                // Sudah dilepas.
            }
        }
        panel = null
        params = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}

private class ToggleRow(val view: LinearLayout, val sw: Switch)
