package com.echotex.draghs67

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    private lateinit var repo: SettingsRepository
    private lateinit var permStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = SettingsRepository(this)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(24))
        }

        val title = Ui.label(this, "SETTINGS", 26f, R.color.neon_cyan, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(16))
            Ui.neon(this, R.color.neon_cyan)
        }

        permStatus = Ui.label(this, "", 15f, R.color.text_primary, true)
        val permCard = Ui.card(this, "IZIN OVERLAY").apply {
            addView(permStatus)
            addView(
                Ui.neonButton(this@SettingsActivity, "BUKA PENGATURAN IZIN", R.color.electric_blue, 48).apply {
                    (layoutParams as LinearLayout.LayoutParams).topMargin = dp(10)
                    setOnClickListener { Ui.openOverlayPermission(this@SettingsActivity) }
                }
            )
        }

        val panelSwitch = Switch(this).apply {
            text = "Aktifkan panel overlay"
            textSize = 15f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            setTextColor(getColor(R.color.text_primary))
            isChecked = repo.panelEnabled
            setOnCheckedChangeListener { _, on ->
                repo.panelEnabled = on
                if (!on) stopService(Intent(this@SettingsActivity, OverlayService::class.java))
            }
        }
        val panelCard = Ui.card(this, "PANEL").apply { addView(panelSwitch) }

        val control = sensitivityControl(this, repo)

        val activeLabel = Ui.label(this, "Aktif: ${Presets.ALL[repo.activePreset].label}", 12f, R.color.neon_cyan, true)
        val presetCard = Ui.card(this, "PRESET").apply {
            addView(activeLabel)
            Presets.ALL.forEach { preset ->
                addView(
                    Ui.neonButton(this@SettingsActivity, preset.label, R.color.electric_blue, 44).apply {
                        textSize = 12f
                        (layoutParams as LinearLayout.LayoutParams).topMargin = dp(8)
                        setOnClickListener {
                            repo.activePreset = Presets.ALL.indexOf(preset)
                            repo.sensitivity = preset.value
                            control.refresh()
                            activeLabel.text = "Aktif: ${preset.label}"
                        }
                    }
                )
            }
        }
        val sensCard = Ui.card(this, "SENSITIVITAS").apply {
            addView(control.view)
        }

        val resetBtn = Ui.neonButton(this, "RESET KONFIGURASI", R.color.danger).apply {
            setOnClickListener {
                repo.resetAll()
                panelSwitch.isChecked = true
                control.refresh()
                activeLabel.text = "Aktif: ${Presets.ALL[repo.activePreset].label}"
                Toast.makeText(this@SettingsActivity, "Konfigurasi dikembalikan (sensitivitas 67%).", Toast.LENGTH_SHORT).show()
            }
        }

        val version = Ui.label(
            this, "DRAG HS 67%  v${versionName()}  |  ${getString(R.string.developer)}",
            12f, R.color.text_dim
        ).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(12))
        }

        val backBtn = Ui.neonButton(this, "KEMBALI", R.color.electric_blue).apply {
            setOnClickListener { Ui.back(this@SettingsActivity) }
        }

        listOf(title, Ui.cloudBanner(this, 70), permCard, panelCard, presetCard, sensCard, resetBtn, version, backBtn, Ui.watermark(this)).forEach { content.addView(it) }

        setContentView(Ui.animatedScreen(this, ScrollView(this).apply {
            isFillViewport = true
            addView(content)
        }))
    }

    override fun onResume() {
        super.onResume()
        val ok = Settings.canDrawOverlays(this)
        permStatus.text = if (ok) "● DIIZINKAN" else "● BELUM DIIZINKAN"
        permStatus.setTextColor(getColor(if (ok) R.color.ok_green else R.color.danger))
    }

    @Suppress("DEPRECATION")
    private fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "?"
    } catch (e: Exception) {
        "?"
    }
}
