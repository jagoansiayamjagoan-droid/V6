package com.echotex.draghs67

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var repo: SettingsRepository
    private lateinit var overlayStatus: TextView
    private lateinit var ffStatus: TextView
    private lateinit var overlayBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = SettingsRepository(this)
        setContentView(buildUi(savedInstanceState == null))

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun buildUi(showIntro: Boolean): View {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(24))
        }

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo_gear)
            adjustViewBounds = true
            layoutParams = LinearLayout.LayoutParams(dp(96), dp(96)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(8)
            }
        }

        val title = Ui.label(this, "DRAG HS 67%", 34f, R.color.neon_cyan, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
            Ui.neon(this, R.color.neon_cyan)
        }
        val subtitle = Ui.label(this, "by ${getString(R.string.developer)}  |  v6.0.0", 12f, R.color.text_dim).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.15f
            setPadding(0, dp(4), 0, dp(20))
        }

        val deviceCard = Ui.card(this, "PROFIL PERANGKAT").apply {
            val maker = Build.MANUFACTURER.replaceFirstChar { it.titlecase(Locale.getDefault()) }
            addView(
                Ui.label(
                    this@MainActivity,
                    "$maker ${Build.MODEL}\nAndroid ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
                    15f, R.color.text_primary
                )
            )
        }

        overlayStatus = Ui.label(this, "", 15f, R.color.text_primary, true)
        val overlayCard = Ui.card(this, "IZIN OVERLAY").apply { addView(overlayStatus) }

        ffStatus = Ui.label(this, "", 15f, R.color.text_primary, true)
        val ffCard = Ui.card(this, "FREE FIRE (${GameLauncher.PACKAGE_NAME})").apply { addView(ffStatus) }

        val offlineCard = Ui.card(this, "MODE OFFLINE").apply {
            addView(Ui.label(this@MainActivity, "● AKTIF - semua fitur berjalan tanpa internet", 13f, R.color.ok_green, true))
        }

        val enter = Ui.neonButton(this, "ENTER", R.color.neon_cyan, 76).apply {
            textSize = 24f
            setOnClickListener { onEnter() }
        }
        overlayBtn = Ui.neonButton(this, "OVERLAY", R.color.electric_blue).apply {
            setOnClickListener { onOverlayToggle() }
        }
        val training = Ui.neonButton(this, "TRAINING", R.color.electric_blue).apply {
            setOnClickListener { Ui.go(this@MainActivity, TrainingActivity::class.java) }
        }
        val settings = Ui.neonButton(this, "SETTINGS", R.color.electric_blue).apply {
            setOnClickListener { Ui.go(this@MainActivity, SettingsActivity::class.java) }
        }
        listOf(logo, title, subtitle, Ui.cloudBanner(this, 110), deviceCard, overlayCard, ffCard, offlineCard, enter, overlayBtn, training, settings, Ui.watermark(this))
            .forEach { content.addView(it) }

        val base = if (showIntro) 1900L else 0L
        for (i in 0 until content.childCount) {
            content.getChildAt(i).apply {
                alpha = 0f
                translationY = dp(16).toFloat()
                animate().alpha(1f).translationY(0f).setStartDelay(base + i * 70L).setDuration(350).start()
            }
        }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(content)
        }
        val screen = Ui.animatedScreen(this, scroll)
        if (!showIntro) return screen
        return FrameLayout(this).apply {
            addView(screen)
            addView(IntroView(this@MainActivity))
        }
    }

    private fun refresh() {
        val canDraw = Settings.canDrawOverlays(this)
        overlayStatus.text = if (canDraw) "● DIIZINKAN" else "● BELUM DIIZINKAN"
        overlayStatus.setTextColor(getColor(if (canDraw) R.color.ok_green else R.color.danger))

        val installed = GameLauncher.isInstalled(this)
        ffStatus.text = if (installed) "● TERPASANG" else "● BELUM TERPASANG"
        ffStatus.setTextColor(getColor(if (installed) R.color.ok_green else R.color.danger))

        overlayBtn.text = if (OverlayService.running) "OVERLAY: ON (ketuk untuk matikan)" else "OVERLAY"
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun onEnter() {
        when (val result = GameLauncher.launch(this)) {
            is GameLauncher.Result.Launched -> startOverlayAfterEnter()
            is GameLauncher.Result.NotInstalled ->
                toast("Free Fire (${GameLauncher.PACKAGE_NAME}) belum terpasang di perangkat ini.")
            is GameLauncher.Result.NoLaunchIntent ->
                toast("Free Fire terpasang, tetapi tidak menyediakan intent peluncuran.")
            is GameLauncher.Result.Failed ->
                toast("Gagal membuka Free Fire: ${result.message}")
        }
    }

    /** Setelah Free Fire berhasil dibuka lewat ENTER, panel overlay ikut dinyalakan. */
    private fun startOverlayAfterEnter() {
        if (OverlayService.running || !repo.panelEnabled) return
        if (!Settings.canDrawOverlays(this)) {
            toast("Free Fire dibuka, tetapi overlay belum aktif karena izin overlay belum diberikan.")
            return
        }
        try {
            startForegroundService(Intent(this, OverlayService::class.java))
        } catch (e: Exception) {
            toast("Gagal menjalankan overlay: ${e.message}")
        }
    }

    private fun onOverlayToggle() {
        if (OverlayService.running) {
            stopService(Intent(this, OverlayService::class.java))
        } else if (!repo.panelEnabled) {
            toast("Panel overlay dimatikan di Settings. Nyalakan dulu di sana.")
            return
        } else if (!Settings.canDrawOverlays(this)) {
            toast("Izin overlay diperlukan. Aktifkan lewat halaman pengaturan yang akan terbuka.")
            Ui.openOverlayPermission(this)
            return
        } else {
            try {
                startForegroundService(Intent(this, OverlayService::class.java))
            } catch (e: Exception) {
                toast("Gagal menjalankan overlay: ${e.message}")
                return
            }
        }
        overlayBtn.postDelayed({ refresh() }, 400)
    }
}
