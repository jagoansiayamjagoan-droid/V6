package com.echotex.draghs67

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import java.util.Random
import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.sin

/**
 * Latar animasi untuk panel overlay: gradasi malam bersalju, butiran salju yang turun pelan,
 * dan tumpukan salju di tepi atas panel. Ringan dan berhenti saat view dilepas dari layar.
 */
class PanelSnowView(ctx: Context) : View(ctx) {

    private val count = 28
    private val rnd = Random(5)
    private val fx = FloatArray(count) { rnd.nextFloat() }
    private val fy = FloatArray(count) { rnd.nextFloat() }
    private val fr = FloatArray(count) { rnd.nextFloat() }
    private val fp = FloatArray(count) { rnd.nextFloat() }
    private val cycles = IntArray(count) { 1 + rnd.nextInt(2) }

    private val bgPaint = Paint()
    private val flakePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val capPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(235, 255, 255, 255)
    }

    private var phase = 0f
    private val twoPi = (2.0 * PI).toFloat()

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 9000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bgPaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            Color.argb(245, 4, 10, 28), Color.argb(245, 16, 48, 86),
            Shader.TileMode.CLAMP
        )
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return

        canvas.drawRect(0f, 0f, w, h, bgPaint)

        // Salju turun pelan sambil bergoyang
        val dp1 = context.dp(1).toFloat()
        for (i in 0 until count) {
            val r = dp1 * (0.9f + fr[i] * 1.6f)
            var yy = fy[i] + phase * cycles[i]
            yy -= floor(yy)
            val y = yy * (h + 2f * r) - r
            val x = fx[i] * w + sin(phase * twoPi * cycles[i] + fp[i] * twoPi) * dp1 * 6f
            flakePaint.color = Color.WHITE
            flakePaint.alpha = (90 + 130 * fr[i]).toInt()
            canvas.drawCircle(x, y, r, flakePaint)
        }

        // Tumpukan salju di tepi atas panel
        canvas.drawRect(0f, 0f, w, dp1 * 2f, capPaint)
        var i = 0
        var x = 0f
        while (x < w + dp1 * 10f) {
            val bump = dp1 * (2.5f + (sin(i * 1.9f) + 1f) * 1.6f)
            canvas.drawCircle(x, dp1 * 2f, bump, capPaint)
            x += dp1 * 9f
            i++
        }
    }
}
