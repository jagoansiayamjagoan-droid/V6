package com.echotex.draghs67

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin

/**
 * Elemen UI (bukan latar layar): spanduk langit dengan awan yang bergerak pelan.
 * Dua lapis awan (jauh dan dekat) bergerak dengan kecepatan berbeda, berulang mulus.
 */
class CloudBannerView(ctx: Context) : View(ctx) {

    private class Cloud(
        val fx: Float,      // posisi awal horizontal (0..1)
        val fy: Float,      // posisi vertikal (0..1 dari tinggi)
        val size: Float,    // ukuran relatif terhadap tinggi
        val cycles: Int,    // jumlah putaran per siklus animasi
        val alpha: Int,
        val bob: Float      // amplitudo naik-turun
    )

    private val clouds = listOf(
        Cloud(0.05f, 0.30f, 0.42f, 1, 150, 0.02f),
        Cloud(0.40f, 0.55f, 0.36f, 1, 140, 0.03f),
        Cloud(0.75f, 0.25f, 0.40f, 1, 150, 0.02f),
        Cloud(0.20f, 0.62f, 0.60f, 2, 235, 0.03f),
        Cloud(0.60f, 0.40f, 0.55f, 2, 230, 0.025f),
        Cloud(0.90f, 0.70f, 0.65f, 2, 240, 0.03f)
    )

    private val skyPaint = Paint()
    private val cloudPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val rect = RectF()

    private var phase = 0f
    private val twoPi = (2.0 * PI).toFloat()

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 40000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        val radius = ctx.dp(14).toFloat()
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius)
            }
        }
        clipToOutline = true
        foreground = Ui.rounded(ctx, Color.TRANSPARENT, ctx.getColor(R.color.ice_stroke), 14)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        skyPaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            Color.rgb(12, 36, 84), Color.rgb(96, 165, 215),
            Shader.TileMode.CLAMP
        )
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (!animator.isStarted) return
        if (visibility == VISIBLE) animator.resume() else animator.pause()
    }

    private fun drawCloud(canvas: Canvas, x: Float, y: Float, s: Float, color: Int, alpha: Int) {
        cloudPaint.color = color
        cloudPaint.alpha = alpha
        canvas.drawCircle(x - 0.55f * s, y, 0.38f * s, cloudPaint)
        canvas.drawCircle(x - 0.10f * s, y - 0.28f * s, 0.50f * s, cloudPaint)
        canvas.drawCircle(x + 0.40f * s, y - 0.08f * s, 0.42f * s, cloudPaint)
        canvas.drawCircle(x + 0.80f * s, y + 0.05f * s, 0.30f * s, cloudPaint)
        rect.set(x - 0.90f * s, y, x + 1.10f * s, y + 0.40f * s)
        canvas.drawRoundRect(rect, 0.2f * s, 0.2f * s, cloudPaint)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return

        canvas.drawRect(0f, 0f, w, h, skyPaint)

        for (c in clouds) {
            val s = c.size * h
            val cw = 2.4f * s
            val x = ((c.fx + phase * c.cycles) % 1f) * (w + 2f * cw) - cw
            val y = c.fy * h + sin(phase * twoPi * c.cycles + c.fx * twoPi) * c.bob * h
            // bayangan bawah awan (biru keabu-abuan), lalu badan awan putih
            drawCloud(canvas, x, y + 0.07f * s, s, Color.rgb(150, 185, 220), (c.alpha * 0.55f).toInt())
            drawCloud(canvas, x, y, s, Color.WHITE, c.alpha)
        }
    }
}
